create view v_best_produk as
  select `procurement`.`orders`.`toko`                AS `toko`,
         `procurement`.`orders`.`created_by`          AS `created_by`,
         `procurement`.`orders`.`created_date`        AS `created_date`,
         sum(`procurement`.`detail_order`.`jumlah`)   AS `best_produk`,
         `procurement`.`orders`.`tanggal`             AS `tanggal`,
         dayofmonth(`procurement`.`orders`.`tanggal`) AS `hari`,
         month(`procurement`.`orders`.`tanggal`)      AS `bulan`,
         year(`procurement`.`orders`.`tanggal`)       AS `tahun`,
         `procurement`.`produk`.`nama`                AS `nama`
  from ((`procurement`.`orders` join `procurement`.`detail_order` on ((`procurement`.`orders`.`inv` =
                                                                       `procurement`.`detail_order`.`inv`))) join `procurement`.`produk` on ((
    `procurement`.`detail_order`.`produk` = `procurement`.`produk`.`id`)))
  group by `procurement`.`produk`.`nama`, `procurement`.`orders`.`tanggal`
  order by `procurement`.`detail_order`.`jumlah` desc;

