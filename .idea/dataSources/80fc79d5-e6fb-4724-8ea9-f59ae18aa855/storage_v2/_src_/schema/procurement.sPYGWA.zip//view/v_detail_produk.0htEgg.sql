create view v_detail_produk as
  select `procurement`.`detail_order`.`inv`           AS `inv`,
         `procurement`.`detail_order`.`harga_beli`    AS `harga_beli`,
         `procurement`.`detail_order`.`harga`         AS `harga`,
         `procurement`.`detail_order`.`jumlah`        AS `jumlah`,
         `procurement`.`detail_order`.`diskon`        AS `diskon`,
         `procurement`.`detail_order`.`subtotal`      AS `subtotal`,
         `procurement`.`detail_order`.`id`            AS `id`,
         `procurement`.`detail_order`.`created_by`    AS `created_by`,
         `procurement`.`detail_order`.`created_date`  AS `created_date`,
         `procurement`.`detail_order`.`toko`          AS `toko`,
         `procurement`.`produk`.`jenis`               AS `jenis`,
         `procurement`.`produk`.`nama`                AS `nama_produk`,
         `procurement`.`produk`.`kategori`            AS `kategori`,
         `procurement`.`produk`.`berat`               AS `berat`,
         `procurement`.`produk`.`keterangan`          AS `keterangan`,
         `procurement`.`produk`.`diskon`              AS `diskon_produk`,
         `procurement`.`produk`.`harga_beli`          AS `harga_beli_produk`,
         `procurement`.`produk`.`harga_jual_normal`   AS `harga_jual_normal`,
         `procurement`.`produk`.`harga_jual_reseller` AS `harga_jual_reseller`,
         `procurement`.`produk`.`stock`               AS `stock`
  from (`procurement`.`detail_order` join `procurement`.`produk` on ((`procurement`.`detail_order`.`produk` =
                                                                      `procurement`.`produk`.`id`)));

