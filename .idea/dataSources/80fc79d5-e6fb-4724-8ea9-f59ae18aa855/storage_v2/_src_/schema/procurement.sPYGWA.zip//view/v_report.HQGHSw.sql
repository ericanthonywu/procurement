create view v_report as
  select `procurement`.`report`.`tanggal`                                                     AS `tanggal`,
         dayname(`procurement`.`report`.`tanggal`)                                            AS `nama_hari`,
         (case dayofweek(`procurement`.`report`.`tanggal`)
            when 1 then 'Minggu'
            when 2 then 'Senin'
            when 3 then 'Selasa'
            when 4 then 'Rabu'
            when 5 then 'Kamis'
            when 6 then 'Jumat'
            when 7 then 'Sabtu' end)                                                          AS `nama_hari_indo`,
         dayofmonth(`procurement`.`report`.`tanggal`)                                         AS `hari`,
         month(`procurement`.`report`.`tanggal`)                                              AS `bulan`,
         year(`procurement`.`report`.`tanggal`)                                               AS `tahun`,
         sum(`procurement`.`report`.`gross_sales`)                                            AS `gross_sales`,
         sum(`procurement`.`report`.`net_sales`)                                              AS `net_sales`,
         sum(`procurement`.`report`.`expenses`)                                               AS `expenses`,
         sum(`procurement`.`report`.`transaksi`)                                              AS `transaksi`,
         sum(`procurement`.`report`.`item_terjual`)                                           AS `total_produk`,
         sum(`procurement`.`report`.`ongkir`)                                                 AS `ongkir`,
         sum(`procurement`.`report`.`diskon`)                                                 AS `diskon`,
         sum(`procurement`.`report`.`harga_beli`)                                             AS `harga_beli`,
         (sum(`procurement`.`report`.`net_sales`) - sum(`procurement`.`report`.`harga_beli`)) AS `gross_profit`,
         ((sum(`procurement`.`report`.`net_sales`) - sum(`procurement`.`report`.`harga_beli`)) -
          sum(`procurement`.`report`.`expenses`))                                             AS `net_profit`,
         `procurement`.`report`.`toko`                                                        AS `toko`
  from `procurement`.`report`
  group by `procurement`.`report`.`tanggal`;

