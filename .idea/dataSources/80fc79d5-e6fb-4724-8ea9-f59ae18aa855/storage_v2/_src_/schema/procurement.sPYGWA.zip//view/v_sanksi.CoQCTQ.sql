create view v_sanksi as
  select `procurement`.`sanksi`.`id`                       AS `id`,
         `procurement`.`sanksi`.`tanggal`                  AS `tanggal`,
         `procurement`.`sanksi`.`karyawan`                 AS `karyawan`,
         `procurement`.`sanksi`.`punishment`               AS `punishment`,
         `procurement`.`sanksi`.`nominal`                  AS `nominal`,
         `procurement`.`sanksi`.`created_by`               AS `created_by`,
         dayofmonth(`procurement`.`sanksi`.`created_date`) AS `tgl`,
         month(`procurement`.`sanksi`.`created_date`)      AS `bulan`,
         year(`procurement`.`sanksi`.`created_date`)       AS `tahun`,
         `procurement`.`sanksi`.`waktu`                    AS `waktu`,
         `procurement`.`auth`.`nama`                       AS `nama`,
         `procurement`.`auth`.`username`                   AS `username`,
         `procurement`.`punishment`.`keterangan`           AS `keterangan`,
         `procurement`.`punishment`.`sanksi`               AS `sanksi`,
         `procurement`.`punishment`.`jumlahwaktusanksi`    AS `jumlahwaktusanksi`,
         `procurement`.`punishment`.`satuanwaktu`          AS `satuanwaktu`,
         `procurement`.`sanksi`.`toko`                     AS `toko`
  from ((`procurement`.`sanksi` join `procurement`.`auth` on ((`procurement`.`sanksi`.`karyawan` =
                                                               `procurement`.`auth`.`id`))) join `procurement`.`punishment` on ((
    `procurement`.`sanksi`.`punishment` = `procurement`.`punishment`.`id`)));

