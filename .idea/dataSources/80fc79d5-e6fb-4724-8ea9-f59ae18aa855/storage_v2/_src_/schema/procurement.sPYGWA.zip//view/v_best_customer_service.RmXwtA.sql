create view v_best_customer_service as
  select count(`procurement`.`orders`.`id`)           AS `total_order`,
         sum(`procurement`.`report`.`item_terjual`)   AS `jumlah`,
         `procurement`.`orders`.`toko`                AS `toko`,
         `procurement`.`orders`.`created_by`          AS `created_by`,
         `procurement`.`orders`.`created_date`        AS `created_date`,
         `procurement`.`orders`.`tanggal`             AS `tanggal`,
         dayofmonth(`procurement`.`orders`.`tanggal`) AS `hari`,
         month(`procurement`.`orders`.`tanggal`)      AS `bulan`,
         year(`procurement`.`orders`.`tanggal`)       AS `tahun`,
         `procurement`.`auth`.`nama`                  AS `nama`
  from ((`procurement`.`orders` join `procurement`.`report` on ((`procurement`.`orders`.`inv` =
                                                                 `procurement`.`report`.`kode`))) join `procurement`.`auth` on ((
    `procurement`.`orders`.`cs` = `procurement`.`auth`.`username`)))
  group by `procurement`.`auth`.`nama`, `procurement`.`orders`.`tanggal`
  order by `procurement`.`report`.`item_terjual` desc;

