create view v_dashboard as
  select dayofmonth(`procurement`.`report`.`tanggal`)                                         AS `hari`,
         month(`procurement`.`report`.`tanggal`)                                              AS `bulan`,
         year(`procurement`.`report`.`tanggal`)                                               AS `tahun`,
         sum(`procurement`.`report`.`item_terjual`)                                           AS `total_produk`,
         (sum(`procurement`.`report`.`net_sales`) - sum(`procurement`.`report`.`harga_beli`)) AS `gross_profit`,
         `procurement`.`report`.`toko`                                                        AS `toko`
  from `procurement`.`report`
  group by `procurement`.`report`.`tanggal`;

