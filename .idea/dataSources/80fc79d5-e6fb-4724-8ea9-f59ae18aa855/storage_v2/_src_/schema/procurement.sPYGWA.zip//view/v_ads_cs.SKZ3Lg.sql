create view v_ads_cs as
  select sum(`procurement`.`ads`.`email`)                                               AS `total_email`,
         sum(`procurement`.`ads`.`sms`)                                                 AS `total_sms`,
         sum(`procurement`.`ads`.`wa`)                                                  AS `total_wa`,
         sum(`procurement`.`ads`.`telp`)                                                AS `total_telp`,
         sum(`procurement`.`ads`.`transfer`)                                            AS `total_transfer`,
         sum(`procurement`.`ads`.`transaksi`)                                           AS `total_transaksi`,
         sum(`procurement`.`ads`.`order`)                                               AS `total_order`,
         sum(`procurement`.`ads`.`sales`)                                               AS `total_sales`,
         sum(`procurement`.`ads`.`biaya_iklan`)                                         AS `total_bi`,
         sum(`procurement`.`ads`.`cpl`)                                                 AS `total_cpl`,
         `procurement`.`ads`.`created_by`                                               AS `created_by`,
         `procurement`.`ads`.`created_date`                                             AS `created_date`,
         `procurement`.`ads`.`toko`                                                     AS `toko`,
         `procurement`.`ads`.`id`                                                       AS `id`,
         sum(`procurement`.`ads`.`net_sales`)                                           AS `net_sales`,
         sum(`procurement`.`ads`.`harga_beli`)                                          AS `harga_beli`,
         (sum(`procurement`.`ads`.`net_sales`) - sum(`procurement`.`ads`.`harga_beli`)) AS `total_gp`
  from `procurement`.`ads`
  group by `procurement`.`ads`.`created_by`, `procurement`.`ads`.`created_date`;

