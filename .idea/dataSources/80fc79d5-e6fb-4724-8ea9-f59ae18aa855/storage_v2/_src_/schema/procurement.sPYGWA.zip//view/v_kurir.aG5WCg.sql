create view v_kurir as
  select `procurement`.`orders`.`expedisi`            AS `expedisi`,
         `procurement`.`orders`.`paket`               AS `paket`,
         `procurement`.`orders`.`toko`                AS `toko`,
         `procurement`.`orders`.`created_by`          AS `created_by`,
         `procurement`.`orders`.`tanggal`             AS `tanggal`,
         dayofmonth(`procurement`.`orders`.`tanggal`) AS `hari`,
         month(`procurement`.`orders`.`tanggal`)      AS `bulan`,
         year(`procurement`.`orders`.`tanggal`)       AS `tahun`,
         sum(`procurement`.`orders`.`ongkir`)         AS `total_ongkir`
  from `procurement`.`orders`
  group by `procurement`.`orders`.`expedisi`;

