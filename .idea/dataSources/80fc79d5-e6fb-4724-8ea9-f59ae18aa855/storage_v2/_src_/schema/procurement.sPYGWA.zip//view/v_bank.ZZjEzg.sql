create view v_bank as
  select `procurement`.`bank`.`rekening`                    AS `rekening`,
         `procurement`.`bank`.`nama`                        AS `nama`,
         `procurement`.`bank`.`bank`                        AS `bank`,
         sum(`procurement`.`orders`.`total_order`)          AS `total_order`,
         `procurement`.`orders`.`toko`                      AS `toko`,
         `procurement`.`orders`.`tanggal_bayar`             AS `tanggal`,
         dayname(`procurement`.`orders`.`tanggal_bayar`)    AS `nama_hari`,
         (case dayofweek(`procurement`.`orders`.`tanggal_bayar`)
            when 1 then 'Minggu'
            when 2 then 'Senin'
            when 3 then 'Selasa'
            when 4 then 'Rabu'
            when 5 then 'Kamis'
            when 6 then 'Jumat'
            when 7 then 'Sabtu' end)                        AS `nama_hari_indo`,
         dayofmonth(`procurement`.`orders`.`tanggal_bayar`) AS `hari`,
         month(`procurement`.`orders`.`tanggal_bayar`)      AS `bulan`,
         year(`procurement`.`orders`.`tanggal_bayar`)       AS `tahun`
  from (`procurement`.`orders` join `procurement`.`bank` on ((`procurement`.`orders`.`bank` =
                                                              `procurement`.`bank`.`id`)))
  group by `procurement`.`bank`.`nama`;

