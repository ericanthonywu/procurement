create view v_gaji as
  select `procurement`.`gaji`.`id`              AS `id`,
         `procurement`.`gaji`.`karyawan`        AS `karyawan`,
         `procurement`.`gaji`.`total_sales`     AS `total_sales`,
         `procurement`.`gaji`.`tanggal`         AS `tanggal`,
         `procurement`.`gaji`.`gaji_pokok`      AS `gaji_pokok`,
         `procurement`.`gaji`.`uang_makan`      AS `uang_makan`,
         `procurement`.`gaji`.`tunjangan`       AS `tunjangan`,
         `procurement`.`gaji`.`bonus`           AS `bonus`,
         `procurement`.`gaji`.`gaji_bersih`     AS `gaji_bersih`,
         `procurement`.`gaji`.`ongkir`          AS `ongkir`,
         `procurement`.`gaji`.`sanksi`          AS `sanksi`,
         `procurement`.`gaji`.`pinjaman`        AS `pinjaman`,
         `procurement`.`gaji`.`totalpenerimaan` AS `totalpenerimaan`,
         `procurement`.`gaji`.`totalpotongan`   AS `totalpotongan`,
         `procurement`.`gaji`.`created_by`      AS `created_by`,
         `procurement`.`gaji`.`created_date`    AS `created_date`,
         `procurement`.`gaji`.`toko`            AS `toko`,
         `procurement`.`auth`.`username`        AS `username`,
         `procurement`.`auth`.`email`           AS `email`,
         `procurement`.`auth`.`nama`            AS `nama`
  from (`procurement`.`gaji` join `procurement`.`auth` on ((`procurement`.`gaji`.`karyawan` =
                                                            `procurement`.`auth`.`id`)));

